<footer>
            <div class="footer-area">
              <br> <strong>Park Ticket Management System @ 2024 |  © Copyright All right reserved </strong></br>
                <strong>Phone:</strong><span>909090909090</span><br>
                <strong> Designed by Team TSP from NHCK</strong>
            </div>
        </footer>
