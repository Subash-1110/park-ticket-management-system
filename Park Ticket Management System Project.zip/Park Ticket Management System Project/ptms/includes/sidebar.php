   <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <p style="color: white">PTMS ADMIN</p>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="dashboard.php" aria-expanded="true"><i class="ti-dashboard"></i><span>Dashboard</span></a>
                               
                            </li>

                            <li>
                                <a href="manage-ticket.php" aria-expanded="true"><i class="ti-layout-sidebar-left"></i><span>Manage Ticket Type
                                    </span></a>
                               s
                            </li>
                          
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-folder"></i><span>Ticket</span></a>
                                <ul class="collapse">
                                    <li><a href="add-normal-ticket.php">Add Ticket</a></li>
                                    <li><a href="manage-normal-ticket.php">Manage Ticket</a></li>
                                </ul>
                            </li>
                             <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-folder"></i><span>Foreigners Ticket</span></a>
                                <ul class="collapse">
                                    <li><a href="add-foreigners-ticket.php">Add Ticket</a></li>
                                    <li><a href="manage-foreigners-ticket.php">Manage Ticket</a></li>
                                </ul>
                            </li>
                           
                          <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-folder"></i><span>Reports</span></a>
                                <ul class="collapse">
                                    <li><a href="between-dates-normalreports.php">Ticket Report</a></li>
                                    <li><a href="between-dates-foreignerreports.php">Foreigner ticket Report</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-search"></i><span>Search</span></a>
                                <ul class="collapse">
                                    <li><a href="normal-search.php">Ticket Search</a></li>
                                    <li><a href="foreigner-search.php">Foreigner Ticket Search</a></li>
                                </ul>
                            </li>
                            
                           
                        </ul>
                    </nav>
                </div>
            </div>
        </div>